# Auditoria Completa do Sistema - 14 de Dezembro de 2025

**Objetivo**: Identificar incoerências, desconexões de versão, chamadas a código não existente e correções necessárias para funcionamento pleno.

---

## 1. PROBLEMAS CRÍTICOS ENCONTRADOS

### 🔴 PROBLEMA CRÍTICO #1: Schema.php renomeando coluna errado

**Localização**: [lib/schema.php](lib/schema.php#L58-L62)

**Descrição**: A schema.php está tentando renomear `password_hash` para `password`:
```php
// Linhas 58-62
$passwordHashStmt = $pdo->query("SHOW COLUMNS FROM clima_users LIKE 'password_hash'");
$passwordStmt = $pdo->query("SHOW COLUMNS FROM clima_users LIKE 'password'");
if ($passwordHashStmt->fetch() && !$passwordStmt->fetch()) {
    $pdo->exec("ALTER TABLE clima_users CHANGE password_hash password VARCHAR(255)");
}
```

**Conflito com código Slim**:
- [src/Repository/UserRepository.php](src/Repository/UserRepository.php#L26) espera coluna `password_hash`
- [src/Service/AuthService.php](src/Service/AuthService.php#L31) verifica `password_hash`
- [src/Controller/AdminController.php](src/Controller/AdminController.php#L316) trabalha com `password_hash`

**Impacto**: Se a schema.php rodar em um banco novo (0 usuários), renomeará a coluna para `password`, causando erro de coluna não encontrada em toda a aplicação Slim.

**Solução Necessária**: Remover as linhas 58-62 de [lib/schema.php](lib/schema.php) que fazem a renomeação. A coluna deve ser e permanecer `password_hash`.

---

### 🔴 PROBLEMA CRÍTICO #2: Inconsistência em create() do AdminController

**Localização**: [src/Controller/AdminController.php](src/Controller/AdminController.php#L220-L233)

**Descrição**: O método `createUser()` tenta inserir nome e email, mas [UserRepository.create()](src/Repository/UserRepository.php#L39-L52) só aceita `username` e `passwordHash`:

```php
// Linha 220 em AdminController.php - recebe nome/email
$name = (string)($data['name'] ?? '');
$email = (string)($data['email'] ?? '');

// Linha 225 - chama create() sem passar esses dados
$this->pdo->prepare('INSERT INTO clima_users (username, password_hash, name, email) VALUES ...')
```

Mas [UserRepository.create()](src/Repository/UserRepository.php#L39) faz:
```php
$stmt = $this->pdo->prepare('INSERT INTO clima_users (username, password_hash) VALUES (:u, :p)');
```

**Impacto**: AdminController.php cria usuários com nome/email diretamente via PDO, bypassando o repository. Inconsistência arquitetural.

**Solução Necessária**: Estender `UserRepository.create()` para aceitar opcionais `name` e `email`.

---

### 🟡 PROBLEMA MAIOR #3: Referências a código legado em copilot-instructions

**Localização**: [.github/copilot-instructions.md](copilot-instructions.md)

**Referências a código antigo**:
- Linha 21: Referencia `weather_admin.php` (arquivo legado em `bin/legacy/`)
- Linha 80: Referencia `bin/reset_admin.php` para login falhando (correto, mas misturado com instruções legadas)
- Linha 82: Menciona `weather_admin.php` como ação nova (deveria ser nova rota Slim)

**Impacto**: Novo desenvolvedor pode seguir instruções que apontam para código legado em `bin/legacy/` em vez do novo `public/index.php`.

**Solução Necessária**: Atualizar [copilot-instructions.md](copilot-instructions.md) removendo referências a `weather_admin.php`, `weather_view.php`, `sync_cron.php` do root e apontando todas para rotas Slim 4.

---

## 2. INCOERÊNCIAS ARQUITETTURAIS (Sem falha imediata, mas perigosas)

### 🟠 INCOERÊNCIA #1: Mix de helpers `lib/` com Services Slim

**Situação**: 
- `lib/thinger.php` possui `getConfigValue()`, `setConfigValue()`, `syncWithThinger()`
- `src/Service/ConfigService.php` duplica `getThinger()`, `setThinger()`, `getCronKey()`
- `src/Service/SyncService.php` chama `syncWithThinger()` de `lib/thinger.php`

**Problema**: 
- ConfigService não usa os helpers; em vez disso, acessa o Repository
- SyncService chama direto a função legacy em `lib/thinger.php`
- Duas formas diferentes de acessar/salvar config

**Código em questão**:
- [src/Service/SyncService.php](src/Service/SyncService.php#L21) chama `syncWithThinger($this->pdo)`
- [src/Service/ConfigService.php](src/Service/ConfigService.php) usa `ConfigRepository` instead
- [lib/thinger.php](lib/thinger.php) define ambos

**Impacto**: Confusão sobre qual abordagem usar. Se alguém adiciona nova config, não está claro se deve ir para repository ou helper.

**Solução**: Mover toda lógica de `lib/thinger.php` para `src/Service/` (SyncService, ConfigService) e deixar `lib/` apenas para funções auxiliares ou remover `lib/thinger.php` completamente.

---

### 🟠 INCOERÊNCIA #2: PublicController vs PublicViewService vs index.php legado

**Situação**:
- [src/Controller/PublicController.php](src/Controller/PublicController.php) serve `/` e `/live`
- [src/Service/PublicViewService.php](src/Service/PublicViewService.php) gera dados para views
- `bin/legacy/index.php` é a página pública antiga (AINDA ACESSÍVEL se DocumentRoot apontar para raiz!)

**Problema**: Se servidor aponta para `c:\PROJETOS\clima_ete_novo\` em vez de `c:\PROJETOS\clima_ete_novo\public\`, usuários podem acessar `bin/legacy/index.php` diretamente.

**Impacto**: Confusão de qual página servir como pública. Possível segurança (código duplicado).

**Solução**: Documentar que DocumentRoot DEVE apontar para `public/` e considerar remover `bin/legacy/`.

---

## 3. DESCONEXÕES DE VERSÃO

### ✅ Bem separado - Slim 4 vs Legacy

**Status**: Bem feito. Código legado está isolado em `bin/legacy/`:
- `bin/legacy/index.php` (página pública antiga)
- `bin/legacy/weather_admin.php` (admin antigo)
- `bin/legacy/weather_view.php` (view ao vivo antigo)
- `bin/legacy/sync_cron.php` (cron antigo)

**Nenhuma referência cruzada** do código Slim 4 para legacy (✅ CORRETO).

### ⚠️ Versões de senha (não é bug, mas confuso)

- `lib/db.php` centraliza PDO
- `lib/schema.php` cria tabelas com `password_hash`
- `AuthService` / `UserRepository` esperam `password_hash`
- **MAS** `lib/schema.php` tenta renomear para `password` (PROBLEMA #1)

---

## 4. ROTAS vs MÉTODOS (Validação)

### ✅ Rotas bem mapeadas

| Rota | Método Controller | Status |
|------|-------------------|--------|
| `GET /` | `PublicController::home()` | ✅ Existe |
| `GET /live` | `PublicController::live()` | ✅ Existe |
| `GET /admin/login` | `AuthController::loginView()` | ✅ Existe |
| `POST /admin/login` | `AuthController::login()` | ✅ Existe |
| `GET /admin/logout` | `AuthController::logout()` | ✅ Existe |
| `GET /admin` | `AdminController::dashboard()` | ✅ Existe |
| `POST /admin/settings` | `AdminController::settings()` | ✅ Existe |
| `POST /admin/sync` | `AdminController::syncNow()` | ✅ Existe |
| `POST /admin/profile` | `AdminController::profile()` | ✅ Existe |
| `GET /admin/reports` | `AdminController::reports()` | ✅ Existe |
| `GET /admin/users/list` | `AdminController::listUsers()` | ✅ Existe |
| `POST /admin/users/create` | `AdminController::createUser()` | ✅ Existe |
| `POST /admin/users/delete/{id}` | `AdminController::deleteUser()` | ✅ Existe |
| `GET /cron/sync` | `CronController::sync()` | ✅ Existe |
| `GET /setup` | `SetupController::view()` | ✅ Existe |
| `POST /setup` | `SetupController::run()` | ✅ Existe |

---

## 5. VALIDAÇÃO DE FUNÇÕES PRIVADAS

### ✅ Todas as funções chamadas existem

- `AdminController::isAdmin()` - ✅ Definida na linha 682
- `AdminController::escape()` - ✅ Definida na linha 688  
- `AdminController::buildDashboardHtml()` - ✅ Definida na linha 330
- `AdminController::updateUserPassword()` - ✅ Definida na linha 273
- `AdminController::verifyAndUpdatePassword()` - ✅ Definida na linha 300
- `AdminController::buildMessageAlert()` - ✅ Definida na linha 667
- `escapeHtml()` JavaScript - ✅ Movida para linha 585 (início do script)

---

## 6. DEPENDÊNCIAS DO CONTAINER DI (Slim)

### ✅ Todas as dependências registradas

| Classe | Factory | Status |
|--------|---------|--------|
| `pdo` | `getPdo()` | ✅ OK |
| `UserRepository` | `new UserRepository($pdo)` | ✅ OK |
| `ConfigRepository` | `new ConfigRepository($pdo)` | ✅ OK |
| `HistoricsRepository` | `new HistoricsRepository($pdo)` | ✅ OK |
| `MetricService` | `new MetricService()` | ✅ OK |
| `PublicViewService` | Com deps | ✅ OK |
| `SetupService` | Com deps | ✅ OK |
| `AuthService` | Com deps | ✅ OK |
| `ConfigService` | Com deps | ✅ OK |
| `SyncService` | Com deps | ✅ OK |
| `SetupController` | Com deps | ✅ OK |
| `AuthController` | Com deps | ✅ OK |
| `AdminController` | Com deps | ✅ OK |
| `RelatoriosController` | Instanciado em `AdminController::reports()` | ✅ OK |

---

## 7. MIDDLEWARES (Ordem e Funcionalidade)

### ✅ Ordem correta em [public/index.php](public/index.php#L105-L107)

```php
$app->add(new CsrfMiddleware());      // Adicionado por último = executado primeiro
$app->add(new AuthMiddleware());      // Adicionado segundo = executado segundo
$app->add(new SessionMiddleware());   // Adicionado primeiro = executado terceiro

// Execução real: Session → Auth → CSRF
```

### ✅ CSRF Middleware

- Protege: `/admin/logout`, `/admin/settings`, `/admin/sync`, `/admin/profile`, `/admin/users/create`, `/admin/users/delete/*`
- Exclui: `/admin/login` (correto, evita bloqueio de autenticação)

### ✅ Auth Middleware

- Protege: Qualquer rota iniciada com `/admin`
- Exclui: `/admin/login` especificamente
- Redireciona para login se não autenticado

### ✅ Session Middleware

- Inicia `session_start()` antes de qualquer coisa

---

## 8. ARQUIVOS DOCUMENTAÇÃO (Consistência)

| Arquivo | Conteúdo | Status |
|---------|----------|--------|
| [USUARIOS_RELATORIOS_MD.MD](USUARIOS_RELATORIOS_MD.MD) (raiz) | Atualizado com Slim 4 | ✅ OK |
| [docs/USUARIOS_RELATORIOS_MD.MD](docs/USUARIOS_RELATORIOS_MD.MD) | Cópia em docs/ | ✅ OK |
| [.github/copilot-instructions.md](copilot-instructions.md) | Referencia legacy | ⚠️ DESATUALIZADO |
| [docs/SLIM4_MIGRATION.md](docs/SLIM4_MIGRATION.md) | Documentação migração | ✅ OK |
| [docs/DEPLOY_CHECKLIST.md](docs/DEPLOY_CHECKLIST.md) | Instrução deploy | ✅ OK |
| [docs/DEPLOY_HOSTGATOR.md](docs/DEPLOY_HOSTGATOR.md) | Específico hosting | ✅ OK |

---

## 9. SEGURANÇA

### ✅ RBAC implementado corretamente

- Coluna `role` em `clima_users` ✅
- Sessão armazena `admin_role` ✅
- Método `isAdmin()` verifica role ✅
- Controle condicional em UI ✅

### ✅ CSRF proteção

- Token gerado: `bin2hex(random_bytes(32))` ✅
- Validado com `hash_equals()` ✅
- Exceção para login ✅

### ✅ Senhas

- Usando `password_hash()` com `PASSWORD_DEFAULT` ✅
- Verificado com `password_verify()` ✅
- Nenhuma senha em texto simples ✅

---

## 10. BANCO DE DADOS

### ✅ Schema criação idempotente

- Todas as criações usam `IF NOT EXISTS` ✅
- ALTERs condicionais verificam existência ✅

### ✅ Tabelas necessárias

- `clima_historico` - leituras climáticas ✅
- `clima_config` - configurações ✅
- `clima_users` - usuários e autenticação ✅

### ⚠️ Coluna `password_hash` vs `password`

- Schema cria como `password_hash` (linha 34) ✅
- Schema tenta renomear para `password` (linhas 58-62) ⚠️ **CONFLITO**
- Código Slim espera `password_hash` ✅
- **Resultado**: Se rodar setup em DB novo, vai quebrar Slim!

---

## 11. CÓDIGO DUPLICADO

### 📋 Pequena duplicação (não crítica)

1. **Dados Thinger config**:
   - `lib/thinger.php` - `getConfigValue()` / `setConfigValue()`
   - `src/Service/ConfigService.php` - `getThinger()` / `setThinger()`

2. **Lógica sync**:
   - `lib/thinger.php` - `syncWithThinger()`
   - `src/Service/SyncService.php` - wraps `syncWithThinger()`

**Recomendação**: Consolidar helpers `lib/thinger.php` em Services, ou remover helpers se Services já existem.

---

## 12. TESTES E VERIFICAÇÕES

### ✅ Ferramentas diagnóstico criadas

- [bin/diagnose.php](bin/diagnose.php) - Testa conexão, usuário admin, verificação password
- [bin/dump_columns.php](bin/dump_columns.php) - Lista colunas da tabela
- [bin/reset_admin.php](bin/reset_admin.php) - Reseta admin com compatibilidade

---

## RESUMO EXECUTIVO

### 🔴 Críticos (resolver antes de produção)

1. **Remover renomeação de coluna** em [lib/schema.php](lib/schema.php) linhas 58-62
2. **Estender UserRepository.create()** para aceitar nome/email
3. **Atualizar [copilot-instructions.md](.github/copilot-instructions.md)** removendo referências a legacy

### 🟡 Maiores (resolve quando possível)

1. **Consolidar config** entre `lib/thinger.php` e `src/Service/`
2. **Remover/arquivar** `bin/legacy/` ou documentar claramente que é abandonado
3. **Padronizar** como Services e Repositories interagem com helpers `lib/`

### 🟢 Menores (não prejudicam funcionamento)

1. Pequena duplicação de documentação (raiz + docs/)
2. Múltiplas formas de acessar config (helpers vs services)

---

## CHECKLIST FINAL

- ✅ Arquitetura Slim 4 bem estruturada
- ✅ RBAC implementado
- ✅ Middlewares em ordem correta
- ✅ Rotas mapeadas corretamente
- ✅ Segurança (CSRF, autenticação, senhas)
- ✅ DI Container configurado
- ✅ Código legado isolado
- ⚠️ Schema.php com conflito de coluna
- ⚠️ UserRepository.create() incompleto
- ⚠️ Documentação com referências legacy

**Recomendação**: Resolver os 3 itens críticos ANTES de implantar em produção.

