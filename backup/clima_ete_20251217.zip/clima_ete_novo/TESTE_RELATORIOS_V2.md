# 🧪 Guia Rápido de Testes - Relatórios v2.0

## ⚡ Teste em 5 Minutos

### 1️⃣ Inicie o Servidor
```bash
cd c:\PROJETOS\clima_ete_novo
php -S localhost:8080 -t public
```

**Esperado**: Mensagem similar a:
```
Listening on http://localhost:8080
[Local IP] Accepted connections
```

### 2️⃣ Acesse o Painel Admin
```
http://localhost:8080/admin/reports?period=7
```

**Esperado**:
- Página carrega sem erros
- Logo da escola no topo
- Título "Relatórios"
- Tabela com dados do banco
- Botões "Exportar CSV" e "Exportar PDF"

### 3️⃣ Teste Exportar CSV
```
http://localhost:8080/admin/reports?period=7&format=csv
```

**Esperado**:
- Download automático do arquivo `relatorio_clima_[data].csv`
- Abra em Excel/Calc
- Verifique se dados estão separados por `;`

### 4️⃣ Teste Exportar PDF (Impressão)
```
http://localhost:8080/admin/reports?period=7&format=pdf&emitter=Teste
```

**Esperado**:
1. Página HTML carregada
2. Logo, título, tabela, rodapé visíveis
3. Botão "Imprimir / Salvar como PDF" no meio
4. Clique no botão **OU** pressione **Ctrl+P**
5. Janela de impressão abre
6. Selecione "Salvar como PDF"
7. Escolha pasta e clique "Salvar"

### 5️⃣ Validar PDF
- Abra o arquivo PDF salvo
- Verifique:
  - [x] Logo está visível
  - [x] Título "ESCOLA TÉCNICA..." correto
  - [x] Tabela com colunas: ID, Data/Hora, Temp, Umid, Pressão, UV, Gas, Chuva
  - [x] Dados corretos
  - [x] Rodapé com "Sistema de Monitoramento"

---

## 🎯 Checklist Detalhado

### Ambiente Local
- [ ] PHP 8.3+ instalado
- [ ] MySQL/MariaDB rodando
- [ ] Banco de dados `clima_ete` criado
- [ ] Tabela `clima_historico` com dados

### Código
- [ ] `src/Controller/RelatoriosController.php` existe
- [ ] `src/Controller/AdminController.php` foi atualizado
- [ ] `public/index.php` importa RelatoriosController
- [ ] Sem erros de sintaxe PHP

### Funcionalidades
- [ ] HTML relatório carrega
- [ ] CSV download funciona
- [ ] PDF (HTML) exibe corretamente
- [ ] Modal de emitter abre
- [ ] Impressão (Ctrl+P) apresenta página corretamente

### Dados
- [ ] Tabela mostra registros do banco
- [ ] Números formatados corretamente (temperatura com 1 decimal)
- [ ] Data exibe em formato DD/MM/YYYY HH:MM
- [ ] Valores especiais (chuva_status) aparecem corretos

### Segurança
- [ ] Caracteres especiais escapados (< > & " ')
- [ ] SQL usa prepared statements
- [ ] Autenticação requerida para /admin/reports
- [ ] Session validada

---

## 🔧 Possíveis Problemas e Soluções

### ❌ Erro 404 em /admin/reports
**Causa**: Rota não registrada  
**Solução**: Verificar `public/index.php` tem `->get('/admin/reports', ...)`

### ❌ RelatoriosController não encontrado
**Causa**: Use statement faltando  
**Solução**: Verificar em `public/index.php`:
```php
use App\Controller\RelatoriosController;
```

### ❌ Tabela vazia no relatório
**Causa**: Banco de dados sem dados ou conexão falhou  
**Solução**:
1. Verificar DB em `db_config.php`
2. Confirmar tabela `clima_historico` existe
3. Confirmar tem registros: `SELECT COUNT(*) FROM clima_historico`

### ❌ Modal não abre
**Causa**: JavaScript não carregou  
**Solução**: Verificar em browser console (F12):
- Lucide icons carregou?
- Erro de JavaScript?

### ❌ PDF não salva ao usar Ctrl+P
**Causa**: Navegador configurado para preview antes  
**Solução**: 
1. Clique no botão "Imprimir / Salvar como PDF" na página
2. Janela de impressão abre
3. Selecione "Salvar como PDF" na opção destino

### ❌ Caracteres especiais aparecem errado
**Causa**: Encoding não UTF-8  
**Solução**: Verificar:
```php
<meta charset="UTF-8">
declare(strict_types=1);
header('Content-Type: text/html; charset=utf-8');
```

---

## 📋 Teste de Regressão

Após qualquer mudança, testar:

```bash
# 1. Verificar sintaxe
php -l src/Controller/RelatoriosController.php
php -l src/Controller/AdminController.php

# 2. Iniciar servidor
php -S localhost:8080 -t public

# 3. Acessar cada endpoint
curl http://localhost:8080/admin/reports?period=7
curl http://localhost:8080/admin/reports?period=7&format=csv
curl http://localhost:8080/admin/reports?period=7&format=pdf&emitter=Teste

# 4. Verificar respostas
# - HTML deve ter <html> e estrutura completa
# - CSV deve ter cabeçalhos e linhas
# - PDF (HTML) deve ter <html> com CSS print
```

---

## 🚀 Teste em Produção (HostGator)

Após fazer deploy:

1. **Acesse**:
   ```
   https://clima.cria.click/admin/reports?period=7
   ```

2. **Verificar**:
   - [x] Página carrega sem erro 500
   - [x] Dados aparecem corretamente
   - [x] CSV download funciona
   - [x] Impressão funciona em navegador

3. **Se erro 500**:
   - Verificar `/home3/terr6836/clima.cria.click/logs/` (se existir)
   - Verificar upload dos 3 arquivos corretos
   - Confirmar namespaces e imports

4. **Se dados vazios**:
   - Verificar conexão banco em `db_config.php`
   - Confirmar timezone correto (America/Recife)
   - Verificar se tabela `clima_historico` tem registros

---

## 📊 Exemplo de Saída Esperada

### Relatório HTML
```
ESCOLA TÉCNICA ESTADUAL PEDRO LEÃO LEAL
ESPAÇO CRIA
PROF. COORDENADOR Francisco Leonardo de Lima

Período: Últimos 7 dias
Data de Emissão: 14/12/2025 10:30:45
Emitido por: João Silva
Total de Registros: 42

┌─────┬──────────────────┬─────────┬────────┬──────────┬─────┬──────┬────────┐
│ ID  │   Data/Hora      │ Temp(°C)│Umid(%) │Pressão   │ UV  │ Gas  │ Chuva  │
├─────┼──────────────────┼─────────┼────────┼──────────┼─────┼──────┼────────┤
│ 100 │ 14/12/2025 10:00 │  27.5   │  65    │ 1013.2   │ 3.2 │ 50.0 │ Não    │
│ 99  │ 14/12/2025 09:45 │  27.3   │  66    │ 1013.1   │ 3.1 │ 51.0 │ Não    │
│ ... │      ...         │   ...   │  ...   │   ...    │ ... │  ... │  ...   │
└─────┴──────────────────┴─────────┴────────┴──────────┴─────┴──────┴────────┘
```

### CSV Export
```csv
ID;Data/Hora;Temperatura(°C);Umidade(%);Pressão(hPa);UV;Gas(KΩ);Chuva;Status Chuva
100;2025-12-14 10:00:00;27.5;65;1013.2;3.2;50.0;0.0;Não
99;2025-12-14 09:45:00;27.3;66;1013.1;3.1;51.0;0.0;Não
```

---

## 💡 Dicas de Debug

### Ver erros no navegador
1. Abra DevTools (F12)
2. Vá em "Console"
3. Procure por mensagens de erro em vermelho

### Ver resposta HTTP completa
```bash
curl -v http://localhost:8080/admin/reports?period=7
```

### Testar SQL direto
```bash
mysql -u root -p clima_ete -e "SELECT COUNT(*) FROM clima_historico;"
```

### Ver logs do PHP (se existir)
```bash
tail -f /var/log/php-errors.log
```

---

## ✅ Status Após Testes

Ao completar todos os testes, você terá:

- ✅ Relatório HTML funcional
- ✅ Export CSV funcionando
- ✅ Export PDF (via impressão) funcionando
- ✅ Dados corretos no banco
- ✅ Segurança validada
- ✅ Pronto para produção

---

**Versão**: 2.0 (HTML + CSS)  
**Última Atualização**: 14 de dezembro de 2025  
**Status**: ✅ PRONTO PARA TESTES
