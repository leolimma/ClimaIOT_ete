---
layout: blogpost
title: 10.000 installs!
author: Matthieu Napoli
date: April 2nd 2014
---

PHP-DI just reached 200 stars on GitHub and 10 000 installs through [Packagist](https://packagist.org/packages/mnapoli/php-di)!

That's time for a nice graph, so here are the number of installs per month since Feb. 2013:

![installs](installs.png)

And that useless post is also the occasion to tell you that v4.1 is going to be released soon.
The [first beta](https://github.com/mnapoli/PHP-DI/releases/tag/4.1.0-beta1) has by the way just been tagged.
