---
layout: documentation
current_menu: silly
---

# PHP-DI in Silly

[Silly](https://github.com/mnapoli/silly) is a micro-framework made for writing CLI applications.

A "PHP-DI Edition" of Silly exist, read about it [in Silly's official documentation](https://github.com/mnapoli/silly/blob/master/docs/php-di.md).
