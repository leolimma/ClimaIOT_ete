---
layout: documentation
current_menu: zend-expressive
---

# PHP-DI in Zend Expressive

[zend-phpdi-config](https://packagist.org/packages/elie29/zend-phpdi-config) acts as a bridge to configure a PSR-11 compatible [PHP-DI](http://php-di.org). It uses autowirng technique, cache compilation and cache definitions as defined in [PHP-DI](http://php-di.org).

## More

Read more on the [zend-phpdi-config project on GitHub](https://github.com/elie29/zend-di-config).
