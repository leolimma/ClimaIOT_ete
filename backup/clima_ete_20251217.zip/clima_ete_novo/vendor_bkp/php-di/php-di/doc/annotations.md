---
layout: documentation
current_menu: annotations
---

# Annotations

**Since PHP-DI 7, annotations have been replaced by [PHP attributes](attributes.md).**
