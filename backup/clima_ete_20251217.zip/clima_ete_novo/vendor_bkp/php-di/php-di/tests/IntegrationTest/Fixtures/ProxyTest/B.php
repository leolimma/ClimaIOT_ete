<?php

declare(strict_types=1);

namespace DI\Test\IntegrationTest\Fixtures\ProxyTest;

class B
{
}
