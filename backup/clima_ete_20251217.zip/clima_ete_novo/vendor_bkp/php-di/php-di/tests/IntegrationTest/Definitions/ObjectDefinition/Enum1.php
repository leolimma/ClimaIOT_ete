<?php

declare(strict_types=1);

namespace DI\Test\IntegrationTest\Definitions\ObjectDefinition;

enum Enum1
{
    case Foo;
    case Bar;
    Case Baz;
}
