<?php

declare(strict_types=1);

return [
    'foo1' => 'bar1',
];
