<?php

declare(strict_types=1);

namespace DI\Test\IntegrationTest\Fixtures;

interface Interface2
{
}
