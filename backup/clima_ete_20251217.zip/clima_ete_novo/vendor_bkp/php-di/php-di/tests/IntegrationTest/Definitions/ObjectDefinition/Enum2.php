<?php

declare(strict_types=1);

namespace DI\Test\IntegrationTest\Definitions\ObjectDefinition;

enum Enum2: string
{
    case Foo = 'foo';
    case Bar = 'bar';
    Case Baz = 'baz';
}
