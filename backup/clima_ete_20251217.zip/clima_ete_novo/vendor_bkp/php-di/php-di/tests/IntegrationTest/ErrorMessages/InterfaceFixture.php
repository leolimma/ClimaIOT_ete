<?php

declare(strict_types=1);

namespace DI\Test\IntegrationTest\ErrorMessages;

interface InterfaceFixture
{
}
