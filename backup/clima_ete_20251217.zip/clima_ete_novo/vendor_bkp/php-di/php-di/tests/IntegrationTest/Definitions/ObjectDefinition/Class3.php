<?php

declare(strict_types=1);

namespace DI\Test\IntegrationTest\Definitions\ObjectDefinition;

class Class3
{
    public function __construct(Class1 $parameter)
    {
    }
}
