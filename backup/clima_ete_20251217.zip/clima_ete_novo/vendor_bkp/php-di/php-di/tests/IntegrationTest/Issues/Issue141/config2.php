<?php

declare(strict_types=1);

return [
    'foo2' => 'bar2',
];
