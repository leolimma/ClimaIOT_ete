<?php

declare(strict_types=1);

namespace DI\Test\IntegrationTest\Fixtures;

/**
 * Fixture class.
 */
class Implementation1 implements Interface1
{
}
