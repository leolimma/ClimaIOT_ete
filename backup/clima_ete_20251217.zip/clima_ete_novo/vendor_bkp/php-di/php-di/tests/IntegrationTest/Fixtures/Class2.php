<?php

declare(strict_types=1);

namespace DI\Test\IntegrationTest\Fixtures;

/**
 * Fixture class.
 */
class Class2
{
    /**
     * @return bool
     */
    public function getBoolean()
    {
        return true;
    }
}
