<?php

declare(strict_types=1);

namespace DI\Test\PerformanceTest\Get;

class GetFixture
{
    public function __construct()
    {
    }
}
