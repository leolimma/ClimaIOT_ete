<?php

declare(strict_types=1);

return [
    'object1'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object2'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object3'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object4'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object5'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object6'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object7'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object8'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object9'  => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
    'object10' => \DI\create('DI\Test\PerformanceTest\Get\GetFixture'),
];
