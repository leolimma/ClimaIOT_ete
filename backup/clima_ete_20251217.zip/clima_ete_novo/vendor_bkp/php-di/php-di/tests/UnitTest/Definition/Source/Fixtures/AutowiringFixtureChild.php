<?php

declare(strict_types=1);

namespace DI\Test\UnitTest\Definition\Source\Fixtures;

/**
 * Fixture class for the ReflectionBasedAutowiring tests.
 */
class AutowiringFixtureChild extends AutowiringFixture
{
}
