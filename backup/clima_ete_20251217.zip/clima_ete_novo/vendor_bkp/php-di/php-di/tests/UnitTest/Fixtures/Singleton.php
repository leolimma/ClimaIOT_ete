<?php

declare(strict_types=1);

namespace DI\Test\UnitTest\Fixtures;

use DI\Attribute\Injectable;

#[Injectable]
class Singleton
{
}
