<?php

declare(strict_types=1);

namespace DI\Test\UnitTest\Attributes\Fixtures;

class Dependency
{
}
