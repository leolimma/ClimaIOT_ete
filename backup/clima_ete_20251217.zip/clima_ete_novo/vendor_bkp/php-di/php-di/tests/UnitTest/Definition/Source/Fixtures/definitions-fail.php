<?php

declare(strict_types=1);

return [
    'foo' => 'bar',
    'baz', // error => this entry is not indexed by a string
];
