<?php

declare(strict_types=1);

namespace DI\Test\UnitTest\Definition\Helper\Fixtures;

class Class1
{
    public function __construct($param1)
    {
    }

    public function method($param1, $param2)
    {
    }
}
