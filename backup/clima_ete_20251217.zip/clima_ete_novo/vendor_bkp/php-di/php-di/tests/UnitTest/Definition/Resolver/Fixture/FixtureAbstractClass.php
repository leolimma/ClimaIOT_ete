<?php

declare(strict_types=1);

namespace DI\Test\UnitTest\Definition\Resolver\Fixture;

abstract class FixtureAbstractClass
{
}
