<?php

namespace Tests\Fixtures;

#[Attribute(Attribute::TARGET_METHOD | Attribute::TARGET_FUNCTION)]
class ModelAttribute
{
    // ..
}
