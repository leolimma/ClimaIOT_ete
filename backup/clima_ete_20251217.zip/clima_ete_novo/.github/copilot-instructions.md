# Instruções para Agentes de Código (Projeto Estação Climática ETE)

Estas regras tornam agentes de IA imediatamente produtivos neste projeto PHP simples (MySQL + Tailwind UI + Thinger.io).

## Arquitetura e Fluxos
- **Backend PHP**: páginas em raiz servem views e ações administrativas.
  - Página pública: [index.php](index.php)
  - Console admin: [weather_admin.php](weather_admin.php)
  - Painel ao vivo: [weather_view.php](weather_view.php) (UI, segue padrões do index)
  - Rotina de sync: [sync_cron.php](sync_cron.php)
  - Slim 4 app (novo): [public/index.php](public/index.php) com controladores em [src/Controller](src/Controller)
    - Middlewares: [src/Middleware/SessionMiddleware.php](src/Middleware/SessionMiddleware.php), [src/Middleware/AuthMiddleware.php](src/Middleware/AuthMiddleware.php), [src/Middleware/CsrfMiddleware.php](src/Middleware/CsrfMiddleware.php)
    - Repositórios/Serviços: [src/Repository](src/Repository), [src/Service](src/Service)
- **Camada de dados**: helpers em [lib/db.php](lib/db.php), [lib/schema.php](lib/schema.php), [lib/thinger.php](lib/thinger.php).
  - `getPdo()` centraliza conexão via `db_config.php` e variáveis de ambiente.
  - `ensureSchema()` cria/atualiza tabelas: `clima_historico`, `clima_config`, `clima_users`.
  - `syncWithThinger()` consome Thinger.io e persiste leituras em `clima_historico` (inclui `chuva_status`).
- **Estado e segurança**:
  - Admin usa `session_start()` + CSRF simples (`ensureCsrfToken()`/`isValidCsrfToken()`).
  - Login com `clima_users` e `password_hash`, lock por tentativas (constantes `LOGIN_MAX_ATTEMPTS`/`LOGIN_BLOCK_SECONDS`).
  - Cron protegido por chave em `clima_config.cron_key` ou env `CLIMA_CRON_KEY`.
  - RBAC: `clima_users.role` com valores `admin` e `user`. Sessão armazena `admin_role`. UI e endpoints condicionais.
  - Middlewares (Slim): Ordem desejada `SessionMiddleware` → `AuthMiddleware` → `CsrfMiddleware`. Não proteger CSRF no `POST /admin/login`.

## Convenções do Projeto
- **Estilo**: PHP com `declare(strict_types=1)`, tratamento de erros com `try/catch` e `error_log`, HTML com Tailwind + Lucide.
- **Formatação de métricas**: funções de classificação em [index.php](index.php) traduzem leituras em chips com tom (`emerald`, `sky`, `amber`, `orange`, `red`, `gray`). Reutilize esse padrão para novas métricas.
- **Persistência de payload**: `persistThingerPayload()` normaliza tipos (`float`/`int`) e calcula `chuva_status` via `determineRainStatus()`.
- **Configurações**: chaves de API e parâmetros ficam em `clima_config` via `getConfigValue()`/`setConfigValue()`. Banco: use `.env` (DB_HOST, DB_NAME, DB_USER, DB_PASS, DB_CHARSET); `db_config.php` descontinuado.
- **Segurança operacional**: [setup.php](setup.php) marca `setup_done` e recomenda remover `setup.php` e [lib/schema.php](lib/schema.php) após provisionamento.
 - **Compatibilidade de senha**: O sistema aceita `clima_users.password` (novo) e `clima_users.password_hash` (antigo). `AuthService` e `UserRepository` tratam ambos.
 - **RBAC**: `clima_users.role` com valores `admin` e `user`. Salvar em sessão `admin_role` e usar `isAdmin()` nos controladores para gates.

## Workflows de Desenvolvimento
- **Provisionar DB**:
  - Via web: acessar [setup.php](setup.php) e executar.
  - Via CLI (Windows PowerShell):
    ```powershell
    php setup.php
    ```
- **Sincronizar dados (manual)**: no admin, ação `sync_now` em [weather_admin.php](weather_admin.php); programável via [sync_cron.php](sync_cron.php) com chave.
  - Web cron: `https://seu-site/sync_cron.php?key=SUA_CHAVE`
  - CLI cron:
    ```powershell
    php sync_cron.php -k=SUA_CHAVE
    ```
- **Configurar Thinger.io**: usar painel admin para `thinger_user`, `thinger_device`, `thinger_resource`, `thinger_token`. O token aceita `Bearer ...` ou somente o valor.
 - **Fluxo Slim 4 (novo)**:
   - Login: `GET/POST /admin/login` (CSRF não exigido no POST)
   - Dashboard: `GET /admin` (exibe seções conforme role)
   - Configurações: `POST /admin/settings` (admin)
   - Sincronização: `POST /admin/sync` (admin)
   - Perfil: `POST /admin/profile` (alterar senha própria)
   - Relatórios: `GET /admin/reports`
   - Usuários: `GET /admin/users/list`, `POST /admin/users/create`, `POST /admin/users/delete/{id}` (admin)
 - **Ordenação de Middlewares**:
   - Desejado: `SessionMiddleware` → `AuthMiddleware` → `CsrfMiddleware`
   - Justificativa: sessão deve existir antes de validar autenticação e CSRF; `POST /admin/login` não exige CSRF.

## Padrões de Código (faça igual)
- **Conexão DB**: sempre use `getPdo()`; não crie conexões ad-hoc.
- **Criação de tabelas**: amplie `ensureSchema()` para novos campos/tabelas; mantenha idempotência e pequenos `ALTER` condicionais.
- **Acesso a configs**: leia/escreva com `getConfigValue()`/`setConfigValue()`; não acesse `clima_config` diretamente sem prepared statements.
- **Tratamento HTTP**: valide CSRF em ações POST no admin; sanitize com `cleanInput()` e `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')` ao renderizar.
  - Exceção: não exigir CSRF em `POST /admin/login`.
- **UI**: componha cards/chips com Tailwind seguindo tons já usados; evite inline CSS complexo.
  - UI condicional por role: seções de Sync/Config/Usuários visíveis apenas para `admin`. Relatórios e Alterar Senha visíveis para todos.
  - Modais: Alterar senha (todos), Gerenciar usuários (apenas admin). Carregar lista via `GET /admin/users/list` com fetch.

## Integrações e Pontos de Extensão
- **Thinger.io**: construa URL com `getThingerSettings()` que inclui `encodeThingerResourcePath()`. Se adicionar recursos, mantenha cabeçalhos `Authorization: Bearer` e `Accept`.
- **Export/relatórios**: [weather_admin.php](weather_admin.php) já inclui `jspdf`/`autotable`; ao criar relatórios, leia de `clima_historico` com paginação simples.
- **Novas métricas**: ao persistir, siga `persistThingerPayload()` para tipos e formatação; ao exibir, adicione classificadores similares aos de temperatura/umidade/UV/air.
 - **Usuários e RBAC**: usar `role` em `clima_users` e checar via `isAdmin()` nos controladores. No frontend, usar flag `isAdmin` para renderizar condicional.
 - **Auth/CSRF**: não exigir CSRF no `POST /admin/login`; validar CSRF apenas em endpoints sensíveis (`/admin/settings`, `/admin/sync`, `/admin/profile`, `/admin/users/create`, `/admin/users/delete/{id}`).

## Operação e Debug
- **Erros de conexão**: `DatabaseConfigException`/`DatabaseConnectionException` em [lib/db.php](lib/db.php) indicam config ausente/inválida; ajuste [db_config.php](db_config.php) ou variáveis de ambiente (`DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`, `DB_CHARSET`).
- **Falhas Thinger**: `fetchThingerData()` retorna `status/message` com HTTP code e trecho do corpo; loga JSON inválido.
- **Status do sistema**: [index.php](index.php) usa `TIMESTAMPDIFF` para calcular `ONLINE/ATENÇÃO/OFFLINE` (limiares 15 min/1 h). Ajuste conforme necessidade.
 - **Login falhando**: verifique se a coluna de senha vigente é `password` (novo) ou `password_hash` (antigo). Use `bin/reset_admin.php` para resetar admin.
   ```powershell
   php -r "require 'bin/reset_admin.php';"
   ```

## Exemplos Rápidos
- **Adicionar coluna nova** em `clima_historico`: editar [lib/schema.php](lib/schema.php) com `ALTER TABLE` condicional e atualizar `persistThingerPayload()`.
- **Nova ação admin**: em [weather_admin.php](weather_admin.php), trate `$_POST['action']`, valide CSRF, use prepared statements, atualize mensagens `success/warning/error`.
 - **Adicionar role a usuário**:
   ```sql
   UPDATE clima_users SET role='admin' WHERE username='usuario';
   ```
 - **Reordenar middlewares Slim**: em [public/index.php](public/index.php), manter `SessionMiddleware` antes de `AuthMiddleware` e `CsrfMiddleware`.

Se algo estiver ambíguo (p. ex., comportamento do painel ao vivo), me avise para detalharmos ou ajustarmos estas instruções.